// Checkout page specific functionality

document.addEventListener('DOMContentLoaded', function() {
    initializeCheckout();
});

function initializeCheckout() {
    displayOrderSummary();
    setupCheckoutForm();
    setupPaymentMethods();
}

function displayOrderSummary() {
    const orderItemsContainer = document.getElementById('order-items');
    const cart = getCart();
    
    if (!orderItemsContainer || cart.length === 0) {
        // Redirect to menu if cart is empty
        window.location.href = 'menu.html';
        return;
    }
    
    let orderHTML = '';
    let subtotal = 0;
    
    cart.forEach(item => {
        const itemTotal = item.price * item.quantity;
        subtotal += itemTotal;
        
        orderHTML += `
            <div class="order-item">
                <span>${item.dish} x ${item.quantity}</span>
                <span>${formatCurrency(itemTotal)}</span>
            </div>
        `;
    });
    
    const deliveryFee = 30;
    const total = subtotal + deliveryFee;
    
    orderHTML += `
        <div class="order-item total">
            <span>Total</span>
            <span>${formatCurrency(total)}</span>
        </div>
    `;
    
    orderItemsContainer.innerHTML = orderHTML;
    
    // Update summary details
    const orderSubtotal = document.getElementById('order-subtotal');
    const orderTotal = document.getElementById('order-total');
    
    if (orderSubtotal) orderSubtotal.textContent = formatCurrency(subtotal);
    if (orderTotal) orderTotal.textContent = formatCurrency(total);
}

function setupCheckoutForm() {
    const placeOrderBtn = document.getElementById('place-order-btn');
    const deliveryForm = document.getElementById('delivery-form');
    
    if (placeOrderBtn && deliveryForm) {
        placeOrderBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Validate form
            if (!deliveryForm.checkValidity()) {
                deliveryForm.reportValidity();
                return;
            }
            
            // Get form data
            const formData = new FormData(deliveryForm);
            const orderData = Object.fromEntries(formData);
            
            // Get payment method
            const paymentMethod = document.querySelector('input[name="payment"]:checked').value;
            
            // Create order
            const order = createOrder(orderData, paymentMethod);
            
            // Save order and clear cart
            saveOrder(order);
            clearCart();
            
            // Show success message and redirect
            showNotification('Order placed successfully!');
            setTimeout(() => {
                window.location.href = 'tracking.html';
            }, 2000);
        });
    }
}

function setupPaymentMethods() {
    const paymentOptions = document.querySelectorAll('.payment-option input');
    
    paymentOptions.forEach(option => {
        option.addEventListener('change', function() {
            // Update any payment-specific UI if needed
            console.log('Payment method changed to:', this.value);
        });
    });
}

function createOrder(customerData, paymentMethod) {
    const cart = getCart();
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const total = subtotal + 30; // Delivery fee
    
    return {
        id: 'LB' + Date.now().toString().slice(-6),
        items: [...cart],
        customer: customerData,
        payment: paymentMethod,
        subtotal: subtotal,
        deliveryFee: 30,
        total: total,
        status: 'placed',
        timestamp: new Date().toISOString(),
        estimatedDelivery: new Date(Date.now() + 45 * 60000).toISOString() // 45 minutes from now
    };
}

function saveOrder(order) {
    // Save current order
    localStorage.setItem('localbite_current_order', JSON.stringify(order));
    
    // Also save to order history
    const orders = JSON.parse(localStorage.getItem('localbite_orders')) || [];
    orders.push(order);
    localStorage.setItem('localbite_orders', JSON.stringify(orders));
}

// Utility function to get cart (defined in cart.js but duplicated here for completeness)
function getCart() {
    return JSON.parse(localStorage.getItem('localbite_cart')) || [];
}

function clearCart() {
    localStorage.removeItem('localbite_cart');
    updateCartCount();
}

function updateCartCount() {
    const cartCount = document.getElementById('cart-count');
    if (cartCount) {
        const cart = getCart();
        const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
        cartCount.textContent = totalItems;
    }
}