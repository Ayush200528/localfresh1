const mongoose = require('mongoose');
const MenuItem = require('../models/MenuItem');
require('dotenv').config();

const menuItems = [
    {
        name: "Misal Pav",
        description: "Spicy sprout curry topped with farsan & onion",
        price: 80,
        category: "snacks",
        image: "images/misal-pav.jpg",
        popular: true,
        ingredients: ["Sprouts", "Pav", "Farsan", "Onion", "Spices"]
    },
    {
        name: "Vada Pav",
        description: "Fried potato dumpling in pav with chutneys",
        price: 35,
        category: "snacks",
        image: "images/vada-pav.jpg",
        popular: true,
        ingredients: ["Potato", "Pav", "Chutney", "Spices"]
    },
    {
        name: "Pav Bhaji",
        description: "Butter-toasted pav with spicy mashed vegetables",
        price: 100,
        category: "snacks",
        image: "images/pav-bhaji.jpg",
        popular: true,
        ingredients: ["Mixed Vegetables", "Pav", "Butter", "Spices"]
    },
    {
        name: "Poha",
        description: "Flattened rice cooked with onion, mustard seeds & peanuts",
        price: 60,
        category: "snacks",
        image: "images/poha.jpg",
        ingredients: ["Poha", "Onion", "Peanuts", "Mustard Seeds"]
    },
    {
        name: "Sabudana Khichdi",
        description: "Tapioca pearls with peanuts and green chili",
        price: 90,
        category: "snacks",
        image: "images/sabudana-khichdi.jpg",
        ingredients: ["Sabudana", "Peanuts", "Green Chili", "Potato"]
    },
    {
        name: "Pithla Bhakri",
        description: "Gram flour curry with jowar bhakri",
        price: 120,
        category: "meals",
        image: "images/pithla-bhakri.jpg",
        ingredients: ["Gram Flour", "Jowar Flour", "Spices"]
    },
    {
        name: "Thalipeeth",
        description: "Multi-grain flatbread served with curd",
        price: 80,
        category: "snacks",
        image: "images/thalipeeth.jpg",
        ingredients: ["Multi-grain Flour", "Spices", "Onion"]
    },
    {
        name: "Modak",
        description: "Sweet steamed dumpling with coconut filling",
        price: 70,
        category: "desserts",
        image: "images/modak.jpg",
        ingredients: ["Rice Flour", "Coconut", "Jaggery"]
    },
    {
        name: "Kanda Bhaji",
        description: "Crispy onion fritters",
        price: 50,
        category: "snacks",
        image: "images/kanda-bhaji.jpg",
        ingredients: ["Onion", "Gram Flour", "Spices"]
    },
    {
        name: "Solkadhi",
        description: "Refreshing kokum-coconut drink",
        price: 40,
        category: "drinks",
        image: "images/solkadhi.jpg",
        ingredients: ["Kokum", "Coconut", "Spices"]
    }
];

const seedDatabase = async () => {
    try {
        await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/localbite');
        console.log('Connected to MongoDB');
        
        // Clear existing menu items
        await MenuItem.deleteMany({});
        console.log('Cleared existing menu items');
        
        // Insert new menu items
        await MenuItem.insertMany(menuItems);
        console.log('Menu items seeded successfully');
        
        process.exit(0);
    } catch (error) {
        console.error('Seeding error:', error);
        process.exit(1);
    }
};

seedDatabase();